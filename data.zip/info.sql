INSERT INTO "info" ("db_ver","created_at","log") VALUES (2,'2022-01-18',' ');
COMMIT;
